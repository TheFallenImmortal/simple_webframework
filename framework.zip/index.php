<?php
include("core/Application.php");
$app = new Application();
$app->run();