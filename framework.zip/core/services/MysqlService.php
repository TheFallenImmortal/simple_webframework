<?php
class MysqlService {
	
}